// src/stores/auth.ts
import { defineStore } from 'pinia'
import http, { setAccessToken, loadTokenFromStorage, clearAccessToken } from '@/lib/http'

export type MemberPayload = {
  memberId: number | string
  name?: string
  email?: string
} | null

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: loadTokenFromStorage() ?? '',
    member: null as MemberPayload,
    loading: false,
    error: '',
    remember: true, // true=localStorage, false=sessionStorage（http.ts 會用到）
  }),

  getters: {
    isMemberLoggedIn: (s) => !!s.member,
  },

  actions: {
    setRemember(v: boolean) { this.remember = v },

    // ★ 外部登入/註冊後：設 token 並讀取 /me
    async setTokenAndLoadMember(token: string) {
      this.token = token
      setAccessToken(this.token, this.remember)
      const me = await http.get('/api/auth/me') // 期待 { member: {...} }
      this.member = me.data.member
      this.error = ''
    },

    async tryLoadSession() {
      if (this.token) {
        setAccessToken(this.token, this.remember)
        try {
          const me = await http.get('/api/auth/me')
          this.member = me.data.member
          this.error = ''
          return true
        } catch {
          try {
            const r = await http.post('/api/auth/refresh')
            const token = r.data.token as string
            this.token = token
            setAccessToken(token, this.remember)
            const me2 = await http.get('/api/auth/me')
            this.member = me2.data.member
            this.error = ''
            return true
          } catch {
            this.member = null
            this.token = ''
            clearAccessToken()
            return false
          }
        }
      }
      return false
    },

    async login(account: string, password: string) {
      this.loading = true; this.error = ''
      try {
        const r = await http.post('/api/auth/token', { Account: account, Password: password })
        await this.setTokenAndLoadMember(r.data.token)
      } catch (e: any) {
        this.error = e?.response?.data?.message ?? '登入失敗'
        throw e
      } finally {
        this.loading = false
      }
    },

    async loginWithEmailCode(account: string, code: string) {
      this.loading = true; this.error = ''
      try {
        const r = await http.post('/api/auth/login-email', { Account: account, Code: code })
        await this.setTokenAndLoadMember(r.data.token)
      } finally { this.loading = false }
    },

    async sendEmailCode(account: string) {
      await http.post('/api/auth/email/send', { Account: account })
    },

    async loginWithTotp(account: string, code: string) {
      this.loading = true; this.error = ''
      try {
        const r = await http.post('/api/auth/login-totp', { Account: account, Code: code })
        await this.setTokenAndLoadMember(r.data.token)
      } finally { this.loading = false }
    },

    external(provider: 'Google' | 'Facebook' | 'LINE', returnUrl: string) {
      location.href = `/api/auth/external/${provider}?returnUrl=${encodeURIComponent(returnUrl)}`
    },

    async logout() {
      try { await http.post('/api/auth/logout') } catch { /* 忽略錯誤 */ }
      this.member = null
      this.token = ''
      clearAccessToken()
    },
  }
})

// 讓現有檔案可以用 useAuth()
export const useAuth = () => useAuthStore()
