<!-- src/views/AuthCallback.vue -->
<template>
  <div class="shell">正在處理外部登入回應…</div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAuth } from '@/stores/auth'

const router = useRouter()
const auth = useAuth()

const hash = new URLSearchParams(location.hash.replace(/^#/, ''))
const token = hash.get('access_token')
const redirect = new URLSearchParams(location.search).get('redirect') || '/member'

// 對齊「記住我」偏好
const remember = (localStorage.getItem('remember_me') ?? '1') === '1'
auth.setRemember(remember)

if (token) {
  try {
    // ★ 等 setTokenAndLoadMember 完成，TopBar 就會立刻知道
    await auth.setTokenAndLoadMember(token)
    router.replace(redirect)
  } catch {
    router.replace('/login?err=oauth')
  }
} else {
  router.replace('/login?err=oauth')
}
</script>

<style scoped>
.shell { padding: 40px; text-align: center; color: #555; }
</style>
