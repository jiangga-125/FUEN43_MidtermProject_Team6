﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReportMail.Data.Contexts;
using ReportMail.Data.Shop;
using ReportMail.Models.Dto;
using ReportMail.Services;
using ReportMail.Services.Export;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ReportMail.Areas.ReportMail.Controllers
{
	[Area("ReportMail")]
	[Route("ReportMail/[controller]/[action]")]
	public class ReportExportController : Controller
	{
		private readonly ShopDbContext _shop;
		private readonly IExcelExporter _excel;
		private readonly MailService _mail;

		public ReportExportController(ShopDbContext shop, IExcelExporter excel, MailService mail)
		{
			_shop = shop;
			_excel = excel;
			_mail = mail;
		}

		[HttpPost]
		public async Task<IActionResult> SendExcel([FromBody] ReportExportDto dto)
		{
			if (!ModelState.IsValid)
				return BadRequest("收件人或資料格式錯誤");

			// 1) 匯出 Excel
			var (bytes, fileName, contentType) = await _excel.ExportSeriesAsync(
				title: dto.Title,
				subTitle: dto.SubTitle ?? "",
				series: dto.Labels.Zip(dto.Values, (l, v) => (label: l, value: v)).ToList(),
				sheetName: dto.Category + "Report"
			);

			// 2) 發信
			_mail.SendReport(
				to: dto.To,
				subject: dto.Title,
				body: $"<h3>{dto.Title}</h3><p>請查收附件。</p>",
				attachmentName: fileName,
				attachmentBytes: bytes,
				contentType: contentType
			);

			return Ok(new { message = "已寄出", to = dto.To });
		}
	}
}
