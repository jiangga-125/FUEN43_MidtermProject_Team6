﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ReportMail.Models.Dto
{
	public class ReportExportDto
	{
		[Required, EmailAddress]
		public string To { get; set; } = string.Empty;

		[Required]
		public string Category { get; set; } = string.Empty; // line / bar / pie

		[Required]
		public string Title { get; set; } = string.Empty;

		public List<string> Labels { get; set; } = new();
		public List<decimal> Values { get; set; } = new();

		// 預留可擴充
		public string? SubTitle { get; set; }
		public Dictionary<string, object>? Filters { get; set; }
	}
}
