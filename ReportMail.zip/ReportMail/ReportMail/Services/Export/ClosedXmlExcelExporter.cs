﻿using ClosedXML.Excel;
using System.IO;

namespace ReportMail.Services.Export
{
	public class ClosedXmlExcelExporter : IExcelExporter
	{
		public Task<(byte[] Bytes, string FileName, string ContentType)> ExportSeriesAsync(
			string title,
			IEnumerable<(string Label, decimal Value)> points,
			string? subtitle = null,
			string? suggestFileName = null)
		{
			var list = points?.ToList() ?? new();
			using var wb = new XLWorkbook();
			var ws = wb.AddWorksheet("Data");

			// 標題
			ws.Cell(1, 1).Value = title;
			ws.Range(1, 1, 1, 2).Merge().Style.Font.SetBold().Font.SetFontSize(14);
			ws.Cell(2, 1).Value = subtitle ?? $"Generated at {DateTime.Now:yyyy-MM-dd HH:mm}";
			ws.Range(2, 1, 2, 2).Merge().Style.Font.SetFontColor(XLColor.Gray);

			// 表頭
			ws.Cell(4, 1).Value = "Label";
			ws.Cell(4, 2).Value = "Value";
			ws.Range(4, 1, 4, 2).Style.Font.SetBold();

			// 內容
			var r = 5;
			foreach (var p in list)
			{
				ws.Cell(r, 1).Value = p.Label;
				ws.Cell(r, 2).Value = p.Value;
				r++;
			}

			// 格式
			var lastRow = Math.Max(5, r - 1);
			ws.Range(4, 1, lastRow, 2).CreateTable();
			ws.Columns().AdjustToContents();
			ws.SheetView.FreezeRows(4);

			using var ms = new MemoryStream();
			wb.SaveAs(ms);
			var bytes = ms.ToArray();

			var fname = string.IsNullOrWhiteSpace(suggestFileName)
				? $"{San(title)}_{DateTime.Now:yyyyMMddHHmmss}.xlsx"
				: $"{San(suggestFileName)}.xlsx";

			return Task.FromResult((bytes, fname,
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));

			static string San(string s)
			{
				foreach (var ch in Path.GetInvalidFileNameChars()) s = s.Replace(ch, '_');
				return s.Trim();
			}
		}
	}
}
