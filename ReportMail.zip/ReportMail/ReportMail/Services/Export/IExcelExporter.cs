﻿namespace ReportMail.Services.Export
{
	public interface IExcelExporter
	{
		Task<(byte[] Bytes, string FileName, string ContentType)> ExportSeriesAsync(
			string title,                             // 會放到 Excel 標題 & 檔名
			IEnumerable<(string Label, decimal Value)> points,
			string? subtitle = null,                  // 例如：日期區間
			string? suggestFileName = null);         // 自訂檔名（不含副檔名）
	}
}
